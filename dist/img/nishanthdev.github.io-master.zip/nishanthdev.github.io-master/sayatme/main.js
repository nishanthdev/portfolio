//------Add your config here---------------------
firebase.initializeApp({
  apiKey: 'AIzaSyC1kUWEfQIacNes1pql37InbpYz0taoXOw',
  authDomain: 'contactme-b2013.firebaseapp.com',
  projectId: 'contactme-b2013'
});

var db = firebase.firestore();

const docRef = db.collection('contacts');

const date = Date();
// Listen for form submit
document.getElementById('contactForm').addEventListener('submit', submitForm);

// Submit form
function submitForm(e) {
  e.preventDefault();

  console.log('submitted');
  // Get values
  var message = getInputVal('message');

  //-------------------Testing----------------
  console.log('message:', message);
  //---------------------------------------------

  // Save message
  saveMessage(message);

  // Show alert
  document.querySelector('.alert').style.display = 'block';

  // Hide alert after 3 seconds
  setTimeout(function() {
    document.querySelector('.alert').style.display = 'none';
  }, 3000);

  // Clear form
  document.getElementById('contactForm').reset();
}

// Function to get get form values
function getInputVal(id) {
  // @ts-ignore
  return document.getElementById(id).value;
}

// // Save message to firebase
function saveMessage(message) {
  //   var newMessageRef = messagesRef.push();

  db.collection('contacts')
    .add({
      userId: 'testUser',
      email: 'somebody at sayatme',
      type: 'sayatme',
      created_at: date,
      message: message
    })
    .then(function(docRef) {
      var docid = docRef.id;
      console.log('Document written with ID: ', docid);
      //----------------updating----------------------------
      // var batch = db.batch();

      // // Set the value of 'NYC'
      // var updateData = db.collection('contacts').doc(docid);

      // // Update the population of 'SF'
      // batch.update(updateData, { key: docid });

      // // Commit the batch
      // batch.commit().then(function() {
      //   console.log(docid);
      // });
      //------------------------------------------------------
    })
    .catch(function(error) {
      console.error('Error adding document: ', error);
    });
}
//---------------display-------------------------------
// db
//   .collection('contacts')
//   .get()
//   .then(querySnapshot => {
//     querySnapshot.forEach(doc => {
//       console.log(`${doc.id} => ${doc.data()}`);
//     });
//   });
//-----------------------------------------------------
